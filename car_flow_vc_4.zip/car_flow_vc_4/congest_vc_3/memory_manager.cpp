#include "memory_manager.h"

void MemoryManager::deallocate(std::list<OutputTravelDB*> &out_list) {
  int index = 0;
  std::list<OutputTravelDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    delete *output_iter;
  }
  printf("Free result --- travel\n");
}

void MemoryManager::deallocate(std::list<OutputCongestDB*> &out_list) {
  int index = 0;
  std::list<OutputCongestDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    delete *output_iter;
  }
  printf("Free result --- congestion\n");
}

void MemoryManager::deallocate(std::list<OutputCountDB*> &out_list) {
  int index = 0;
  std::list<OutputCountDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    delete *output_iter;
  }
  printf("Free result --- count\n");
}