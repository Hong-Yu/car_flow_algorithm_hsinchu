#ifndef TRAFFIC_ANALYSIS_H_
#define TRAFFIC_ANALYSIS_H_
#include <list>
#include "data_member.h"
class TrafficAnalysis {
 public:
  void set_callist(std::list<CalData> &callist ) { 
    cal_list_ = &callist; 
  }
  void Analysis();
 private:
  void ListToPoint();
  void PointToList();
  void AnalysisProcess();
  void Headway(int total, CalData* content);
  void Filter(int total, CalData* content);
  void LocalAvg(int total, CalData* content);
  void StopAdjust(int total, CalData* content);
  void Congestion(int total, CalData* content);
  void Level(int total, CalData* content);
  std::list<CalData>* cal_list_;
  CalData* caldata_;
  int data_total_;
};

#endif // TRAFFIC_ANALYSIS_H_