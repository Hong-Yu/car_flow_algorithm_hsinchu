#ifndef DATA_COMBINATION_H_
#define DATA_COMBINATION_H_
#include <list>
#include "data_member.h"

class DataCombinationToFile {
 public:
  DataCombinationToFile(int input_total);
  ~DataCombinationToFile();
  void set_classdata(std::list<InputDB> &classdata ) { class_list_ = &classdata; }
  void DataCombine();
 private:
  void AssertRegion();
  void ReadFile();
  void WriteFile();
  void WriteModifyFile();
  int DateConvertor(char* date);
  void DBToMDB(std::list<InputMDB> &mdb_list);
  int input_max_;
  std::list<InputDB>* class_list_;
  InputDB* filedata_;
  InputMDB* mdata_;

  int region_;
  int frecord_total_;
};

#endif //DATA_COMBINATION_H_