#ifndef SETTING_INITIAL_H_
#define SETTING_INITIAL_H_
enum ProcessType {
  kTravel,
  kCongest,
  kCarCount
};

class InitialCondition {
public:
  InitialCondition();
  void Initailize();
  int Period(ProcessType type);
  int Inteval(ProcessType type);
  int LastTime(ProcessType type);
  void LastTime(ProcessType type, int sec);
  int get_last_id(){ return last_id_; };
  void End(int id, int travel, int congest, int count);
private:
  void ReadIniFile();
  void WriteIniFile();
  void ReadUserInterface();
  int CurrentDailyMark();
  int SecFromMidnight();
  void ParameterNewDaySetting();
  void ClearTempFile();
  int daily_mark_;
  int last_id_;
  int period_travel_;
  int period_congest_;
  int period_carcount_;
  int time_delay_;
  int last_time_travel_;
  int last_time_congest_;
  int last_time_carcount_;
  int time_current_;
};


#endif //SETTING_INITIAL_H_