#ifndef READ_TRAFFIC_INFO_H_
#define READ_TRAFFIC_INFO_H_
#include <SQLAPI.h>
#include <vector>

class ReadTrafficInfo {
 public:
   ReadTrafficInfo(SAConnection* con_output);
   ~ReadTrafficInfo();
   void Initialize();
   int Total() { return camera_id_vector_.size(); }
   int Camera(int index) { return camera_num_vector_[index]; }
   int ID(int index) { return camera_id_vector_[index]; }
 private:
   void ReadText();
   void ReadDatabase();
   std::vector<int> camera_id_vector_;
   std::vector<int> camera_num_vector_;
   SAConnection* con_output_;
};


#endif // READ_TRAFFIC_INFO_H_
