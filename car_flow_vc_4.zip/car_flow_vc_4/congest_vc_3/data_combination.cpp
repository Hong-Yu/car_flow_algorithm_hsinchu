#include "data_combination.h"

#include <stdio.h>
#include <stddef.h> // NULL
#include <string.h> // strcpy

#include "manager_time.h"
// Public member function -------------------------------------------
DataCombinationToFile::DataCombinationToFile(int input_total) {
  input_max_ = input_total;
  filedata_ = NULL;
}
DataCombinationToFile::~DataCombinationToFile() {
  if (filedata_ != NULL) delete []filedata_;
}
void DataCombinationToFile::DataCombine() {
  if (!class_list_->size()) return;
  AssertRegion();
  ReadFile();
  WriteFile();
  WriteModifyFile();
  class_list_->clear();
  //ReadFile();
  //class_list_->reverse();

}
// Private member function -------------------------------------------
 void DataCombinationToFile::AssertRegion() {
  std::list<InputDB>::iterator iter_class;
  iter_class = class_list_->begin();
  region_ = iter_class->region_code;
 }
void DataCombinationToFile::ReadFile() {
  char filename[15];
  sprintf(filename, "temp/%d.bin", region_);
  FILE *fptr = fopen(filename, "rb");
  if (fptr == NULL) { 
    return;
  }
  size_t size = sizeof(int);
  size_t count = 1;
  fread(&frecord_total_, size, count, fptr);
  if (filedata_ != NULL) {
    delete []filedata_;
  } 
  filedata_ = new InputDB[input_max_ + frecord_total_];
  size = sizeof(InputDB);
  count = frecord_total_;
  fread(filedata_, size, count, fptr);
  int record_index = frecord_total_ - 1;
  while (record_index--) {
    class_list_->push_front(filedata_[record_index]);
  }
  fclose(fptr);
}

void DataCombinationToFile::WriteFile() {
  char filename[15];
  sprintf(filename, "temp/%d.bin", region_);
  FILE *fptr = fopen(filename, "wb");
  if (fptr == NULL) { 
    return;
  }
  frecord_total_ = class_list_->size();
  size_t size = sizeof(int);
  size_t count = 1;
  fwrite(&frecord_total_, size, count, fptr);
  size = sizeof(InputDB);
  count = 1;
  std::list<InputDB>::iterator iter_class;
  for (iter_class=class_list_->begin(); iter_class!=class_list_->end(); ++iter_class) {
    fwrite(&(*iter_class), size, count, fptr);
  }
  fclose(fptr);
}


void DataCombinationToFile::WriteModifyFile() {
  std::list<InputMDB> mdb_list;
  DBToMDB(mdb_list);
  // BD MDB Convertor 
  char filename[15];
  sprintf(filename, "temp/m%d.bin", region_);
  FILE *fptr = fopen(filename, "wb");
  if (fptr == NULL) { 
    return;
  }
  frecord_total_ = mdb_list.size();
  size_t size = sizeof(int);
  size_t count = 1;
  fwrite(&frecord_total_, size, count, fptr);
  size = sizeof(InputMDB);
  count = 1;
  std::list<InputMDB>::iterator iter_class;
  for (iter_class=mdb_list.begin(); iter_class!=mdb_list.end(); ++iter_class) {
    fwrite(&(*iter_class), size, count, fptr);
  }
  fclose(fptr);
  delete []mdata_;
}

int DataCombinationToFile::DateConvertor(char* date) {
  char midday[10], hour[50];
  int sec;
  /*
  sscanf(date, "%*s %s %s", midday, hour);
  if (strcmp(midday, "�W��")) {
    sec = HourToSec(hour) + 43200;
  } else {
    sec = HourToSec(hour);
  }
  */
  sscanf(date, "%*s %*s %*s %s", hour);
  sec = HourToSec(hour);
  //printf("%s -*- %s %d\n", date, hour, sec);
  //getchar();

  return sec;
}

void DataCombinationToFile::DBToMDB(std::list<InputMDB> &mdb_list) {
  mdb_list.clear();
  mdata_ = new InputMDB[class_list_->size()];
  int record_index = 0;
  std::list<InputDB>::iterator iter_class;
  for (iter_class=class_list_->begin(); iter_class!=class_list_->end(); ++iter_class) {
    mdata_[record_index].serial_no = iter_class->serial_no;
    mdata_[record_index].log_date = DateConvertor(iter_class->log_date);
    strcpy(mdata_[record_index].plate_number, iter_class->plate_number);
    mdata_[record_index].region_code = iter_class->region_code;
    mdb_list.push_back(mdata_[record_index]);
  }
}