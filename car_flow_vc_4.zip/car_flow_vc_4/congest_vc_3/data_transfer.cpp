#include "data_transfer.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

#include "manager_time.h"
//Public member function ---------------------------------------------
DataTransfer::DataTransfer() {
  caldata_ = new CalData[10000];
}
DataTransfer::~DataTransfer() {
  delete[] caldata_;
}

void DataTransfer::ClassToCal(){
  cal_list_->clear();
  std::list<InputMDB>::iterator class_iter;
  int index = 0;
  CalData* cal_cur;
  for (class_iter=class_list_->begin(); class_iter!=class_list_->end(); ++class_iter) {
    cal_cur = &caldata_[index];
    cal_cur->id = class_iter->serial_no;
    strcpy(cal_cur->plate, class_iter->plate_number);
    cal_cur->region =class_iter->region_code;
    cal_cur->valid = true;
    cal_cur->timesec = class_iter->log_date;
    cal_cur->headway = -1;
    cal_cur->localavg = -1;
    cal_cur->congestion = -1;
    cal_cur->level = -1;
    cal_list_->push_back(*cal_cur);
    ++index;
  }
}

void DataTransfer::InsertCongest(int camera_id, int camera_num, int end_time,
                      std::list<OutputCongestDB*> &out_list_congest) {
  OutputCongestDB* congest_data = new OutputCongestDB;
  congest_data->traffic_id = camera_id;
  congest_data->equid = camera_num;
  SecDateConvertor(end_time, congest_data->data_time);
  SecDateConvertor(congest_data->create_time);
  congest_data->data_time_dt = DateTimeSec(end_time);
  congest_data->create_time_dt = DateTimeCurrent();
  if (cal_list_->empty()) {
    congest_data->val = 1;
  } else {
    int val_sum = 0;
    std::list<CalData>::iterator cal_iter;
    for (cal_iter = cal_list_->begin(); cal_iter != cal_list_->end(); ++cal_iter) {
      val_sum += cal_iter->level;
    }
    congest_data->val = val_sum / cal_list_->size();
  }
  if (congest_data->val > 5 || congest_data->val < 1) congest_data->val = 1;
  //printf("%d %s %s %d", congest_data->equid, congest_data->data_time,
   //                  congest_data->create_time, congest_data->val);
  out_list_congest.push_back(congest_data);
}

void DataTransfer::InsertCarCount(int camera_id, int camera_num, int end_time,
                      std::list<OutputCountDB*> &out_list_carcount) {
  OutputCountDB* carcount_data = new OutputCountDB;
  carcount_data->traffic_id = camera_id;
  carcount_data->equid = camera_num;
  SecDateConvertor(end_time, carcount_data->data_time);
  SecDateConvertor(carcount_data->create_time);
  if (cal_list_->empty()) {
    carcount_data->val = 0;
  } else {
    carcount_data->val = cal_list_->size();
  }
  if (carcount_data->val < 0) carcount_data->val = 0;
  carcount_data->data_time_dt = DateTimeSec(end_time);
  carcount_data->create_time_dt = DateTimeCurrent();
  //printf("%d %s %s %d", carcount_data->equid, carcount_data->data_time,
   //                  carcount_data->create_time, carcount_data->val);
  out_list_carcount.push_back(carcount_data);
}

void DataTransfer::InsertTravelTime( int end_time, int road_id, int tot_val,
                      std::list<OutputTravelDB*> &out_list_carcount) {
  OutputTravelDB* tot_data = new OutputTravelDB;
  tot_data->travel_id = road_id;
  SecDateConvertor(end_time, tot_data->data_time);
  SecDateConvertor(tot_data->create_time);
  tot_data->data_time_dt = DateTimeSec(end_time);
  tot_data->create_time_dt = DateTimeCurrent();
  tot_data->d_time = tot_val;
  out_list_carcount.push_back(tot_data);
}

//Private member function --------------------------------------------
void DataTransfer::SecDateConvertor(char* date) {
  char midday[10];
  int hour, minute, sec;
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  hour = timeinfo->tm_hour;
  minute = timeinfo->tm_min;
  sec = timeinfo->tm_sec;
  if (hour >= 12) {
    hour -= 12;
    strcpy(midday, "�U��");
  } else {
    strcpy(midday, "�W��");
  }
  if (hour == 0) {
    hour = 12;  
  }
  sprintf(date, "%d/%d/%d %s %02d:%02d:%02d",
          timeinfo->tm_year + 1900, timeinfo->tm_mon + 1, timeinfo->tm_mday,
          midday, hour, minute, sec);
}

void DataTransfer::SecDateConvertor(int time_sec, char* date) {
  int rest_sec = time_sec;
  char midday[10];
  int hour, minute, sec;
  hour = rest_sec / 3600;
  rest_sec -= hour * 3600;
  minute = rest_sec / 60;
  rest_sec -= minute * 60;
  sec = rest_sec;
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  if (hour >= 12) {
    hour -= 12;
    strcpy(midday, "�U��");
  } else {
    strcpy(midday, "�W��");
  }
  if (hour == 0) {
    hour = 12;
  }
  sprintf(date, "%d/%d/%d %s %02d:%02d:%02d",
          timeinfo->tm_year + 1900, timeinfo->tm_mon + 1, timeinfo->tm_mday,
          midday, hour, minute, sec);
}

DateTime DataTransfer::DateTimeCurrent() {
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  return *timeinfo;
}

DateTime DataTransfer::DateTimeSec(int time_sec) {
  // 1. 
  int rest_sec = time_sec;
  char midday[10];
  int hour, minute, sec;
  hour = rest_sec / 3600;
  rest_sec -= hour * 3600;
  minute = rest_sec / 60;
  rest_sec -= minute * 60;
  sec = rest_sec;
  // 2.
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  timeinfo->tm_hour = hour;
  timeinfo->tm_min = minute;
  timeinfo->tm_sec = sec;
  return *timeinfo;
}