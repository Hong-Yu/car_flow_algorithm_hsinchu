#include "stopwatch.h"
#include <stdio.h>
#include <thread>         // std::this_thread::sleep_for
#include <chrono>         // std::chrono::seconds
void Stopwatch::Decrease(int sec) {
  for (int i=sec; i>0; --i) {
    printf("\r    \r");
    printf("%d", i);
    std::this_thread::sleep_for (std::chrono::seconds(1));
  }
  printf("\r    \n");
}
