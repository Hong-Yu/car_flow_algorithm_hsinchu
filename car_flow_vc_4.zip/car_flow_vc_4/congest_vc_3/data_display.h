#ifndef DATA_DISPLAY_H_
#define DATA_DISPLAY_H_
#include <list>
#include "data_member.h"

class DataListDisplay {
public:
  void Show(std::list<InputDB> &input_list);
  void Show(std::list<InputMDB> &input_list);
  void Show(std::list<CalData> &cal_list);
  void Show(std::list<OutputCongestDB*> &out_list);
  void write(std::list<InputMDB> &input_list);
private:
};

#endif // DATA_DISPLAY_H_