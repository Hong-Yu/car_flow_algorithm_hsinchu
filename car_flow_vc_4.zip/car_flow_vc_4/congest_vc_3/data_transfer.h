#ifndef DATA_TRANSFER_H_
#define DATA_TRANSFER_H_
#include <list>
#include "data_member.h"
class DataTransfer { 
 public:
  DataTransfer();
  ~DataTransfer();
  void set_classlist(std::list<InputMDB> &classlist ) { 
    class_list_ = &classlist; 
  }
  void set_callist(std::list<CalData> &callist ) { 
    cal_list_ = &callist; 
  }
  void ClassToCal();
  void CalToOut();
  void InsertCongest(int camera_id, int camera_num, int star_time,
                      std::list<OutputCongestDB*> &out_list_congest);
  void InsertCarCount(int camera_id, int camera_num, int star_time,
                      std::list<OutputCountDB*> &out_list_carcount);
  void InsertTravelTime(int end_time, int road_id, int tot_val,
                      std::list<OutputTravelDB*> &out_list_carcount);
 private:
  void SecDateConvertor(char* date);
  void SecDateConvertor(int sec, char* date);
  DateTime DateTimeCurrent();
  DateTime DateTimeSec(int time_sec);

  std::list<InputMDB>* class_list_;
  std::list<CalData>* cal_list_;
  CalData* caldata_;
  OutputCongestDB* congest_data_;
};


#endif //DATA_TRANSFER_H_
