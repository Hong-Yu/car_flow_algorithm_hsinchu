
#include <stdio.h>

#include <list>
#include <vector>

#include "database_insert.h"
#include "data_classification.h"
#include "data_combination.h"
#include "data_display.h"
#include "data_member.h"
#include "initial_setting.h"
#include "manager_io.h"
#include "manager_time.h"
#include "memory_manager.h"
#include "sub_process_congest.h"
#include "sub_process_travel.h"
#include "stopwatch.h"
#include "read_traffic_info.h"
#include "read_road_info.h"

#include "database.h"

//#include "data_module.h"

void TrafficDataProcess();

int main () {
  while(true) {
    TrafficDataProcess();
    Stopwatch stopwatch;
    stopwatch.Decrease(30);
  }
  getchar();
}

void ClassifyAndCombinFileProcess(std::list<InputDB>& input_list) {
  // 1. Display input data 
  DataListDisplay display;
  //display.Show(input_list);
  //getchar();
  std::list<InputDB> class_list;
  printf("Begin classification\n");
  DataClassification classif;
  classif.set_rawdata(input_list);
  classif.set_classdata(class_list);
  DataCombinationToFile combine(input_list.size());
  while (classif.RawRemain()) {
    // List container initialize
    class_list.clear();
    // Data process : classify -> combine with file -> calculate congestion
    // -> output.
    classif.Classification(); // split same region data.
    printf("----------- %2d -----------\n", classif.get_camera_id());
    combine.set_classdata(class_list);
    //display.Show(class_list);
    //getchar();
    combine.DataCombine();
    //display.InputDataBase(class_list);
  }
}

void MainProcessCongestion(InitialCondition& inicond, SAConnection* con_device, SAConnection* con_output) {
  // Congestion calculation process --------------------------------------------
  // 1. Prepare output container and set it empty.
  std::list<OutputCongestDB*> output_list_congest;
  output_list_congest.empty();
  // 2. Read information about how many camera should be analysis.
  ReadTrafficInfo trafficinfo(con_device);
  int camera_total = trafficinfo.Total();
  // 3. Get time initial condition.
  int time_start = inicond.LastTime(kCongest);
  int time_inteval = inicond.Inteval(kCongest);
  int time_period = inicond.Period(kCongest);
  for (int camera_index = 0; camera_index < camera_total; camera_index++) {
    int camera_id = trafficinfo.ID(camera_index);
    int camera_num = trafficinfo.Camera(camera_index);
    printf("Congest --- %2d ---\n", camera_num);
    CongestionProcess(camera_id, camera_num, time_start, time_inteval, time_period,
                      output_list_congest);
  }
  // -------------------------------- END --------------------------------
  //DataListDisplay display;
  //display.Show(output_list_congest);
  //WriteDataBaseCongest(output_list_congest);
  WriteTextCongest(output_list_congest);
  DatabaseInsert database(con_output);
  database.Insert(output_list_congest);
  MemoryManager memory;
  memory.deallocate(output_list_congest);
}

void MainProcessCarCount(InitialCondition& inicond, SAConnection* con_device, SAConnection* con_output) {
  // Car count process --------------------------------------------
  // 1. Prepare output container and set it empty.
  std::list<OutputCountDB*> output_list_count;
  output_list_count.empty();
  // 2. Read information about how many camera should be analysis.
  ReadTrafficInfo trafficinfo(con_device);
  int camera_total = trafficinfo.Total();
  // 3. Get time initial condition.
  int time_start = inicond.LastTime(kCarCount);
  int time_inteval = inicond.Inteval(kCarCount);
  int time_period = inicond.Period(kCarCount);
  for (int camera_index = 0; camera_index < camera_total; camera_index++) {
    int camera_id = trafficinfo.ID(camera_index);
    int camera_num = trafficinfo.Camera(camera_index);
    printf("Car count --- %2d ---\n", camera_num);
    CarCountProcess(camera_id, camera_num, time_start, time_inteval, time_period,
                      output_list_count);
  }
  // -------------------------------- END --------------------------------
  //WriteDataBaseCarCount(output_list_count);
  WriteTextCarCount(output_list_count);
  DatabaseInsert database(con_output);
  database.Insert(output_list_count);
  MemoryManager memory;
  memory.deallocate(output_list_count);
}

void MainProcessTravelTime(InitialCondition& inicond, SAConnection* con_device, SAConnection* con_output) {
  // Travel time process --------------------------------------------
  // 1. Prepare output container and set it empty.
  std::list<OutputTravelDB*> output_list_travel;
  output_list_travel.empty();
  // 2. Read information about how many camera should be analysis.
  ReadRoadInfo roadinfo(con_device);
  int camera_total = roadinfo.Total();
  int road_id;
  // 3. Get time initial condition.
  int time_start = inicond.LastTime(kTravel);
  int time_inteval = inicond.Inteval(kTravel);
  int time_period = inicond.Period(kTravel);
  // 4. Prepare parameter for road information.w
  //printf("%d %d %d\n",camera_total, camera_set[0], camera_set[1]);
  for (int road_index = 0; road_index < camera_total; road_index++) {
    if (!roadinfo.get_is_adequate(road_index)) continue;
    std::vector<int> camera_start = roadinfo.get_camera_start(road_index);
    std::vector<int> camera_end = roadinfo.get_camera_end(road_index);
    int default_time = roadinfo.get_default_time(road_index);
    road_id = roadinfo.RoadId(road_index);
  //printf("Travel time --- %2d %2d --- %d %d\n", 
   //      camera_start[0], camera_end[0], road_id, default_time);
    TravelProcess(road_id, camera_start, camera_end, default_time, time_start, time_inteval, time_period,
                  output_list_travel);
  }
  // -------------------------------- END -------------------------------- 
  WriteTextTravelTime(output_list_travel);
  //WriteDataBaseTravelTime(output_list_travel);
  DatabaseInsert database(con_output);
  database.Insert(output_list_travel);
  MemoryManager memory;
  memory.deallocate(output_list_travel);
}

void TrafficDataProcess() {
  printf("Welcome to travel time program.\n");
  //DataModule2->CarRecordTable->Active = false;
  //DataModule2->CarRecordTable->TableName = TableNameToday().c_str();
  //DataModule2->CarRecordTable->Active = true;

  InitialCondition inicond;
  inicond.Initailize();
  int id_last = inicond.get_last_id();

  std::list<InputDB> input_list, class_list;
  Database database;
  database.Connect();
  database.Read(id_last, input_list);
  if (!database.Status()) {
    printf("Database error! restart program.");
    return;
  }
  ClassifyAndCombinFileProcess(input_list);
  SAConnection* con_output = database.get_con_output();
  SAConnection* con_device = database.get_con_device();

  MainProcessTravelTime(inicond, con_device, con_output);
  //getchar();
  MainProcessCarCount(inicond, con_device, con_output);
  MainProcessCongestion(inicond, con_device, con_output);

    //WriteDataBase(out_list);
  //WriteIniInf(id_fal);
  inicond.End(id_last, 0 ,0 ,0);
  database.Disconnect();
}
