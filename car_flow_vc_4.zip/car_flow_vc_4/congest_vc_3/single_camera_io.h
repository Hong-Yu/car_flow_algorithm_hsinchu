
#ifndef SINGLE_CAMERAIO_H_
#define SINGLE_CAMERAIO_H_

#include <list>
#include "data_member.h"

class SingleCameraIO {
 public:
  SingleCameraIO();
  ~SingleCameraIO();
  void set_list(std::list<InputMDB> &scamr_list) { scamr_list_ = &scamr_list; }
  void ReadSingleCameraData(int id);
 private:
   void FilterDuplicate(std::list<InputMDB> &input_list);
   std::list<InputMDB>* scamr_list_;
   InputMDB* file_data_;
};

#endif // SINGLE_CAMERAIO_H_