#include "traffic_analysis.h"

#include "manager_time.h"

void TrafficAnalysis::Analysis() {
  if (cal_list_->size() <= 3) return; 
  ListToPoint();
  AnalysisProcess();
  PointToList();
}

void TrafficAnalysis::ListToPoint() {
  int record_total = cal_list_->size();
  caldata_ = new CalData[record_total];
  std::list<CalData>::iterator cal_iter;
  int record_index = 0;
  CalData* cal_cur;
  for (cal_iter = cal_list_->begin(); cal_iter != cal_list_->end(); ++cal_iter) {
    cal_cur = &(*cal_iter);
    caldata_[record_index] = *cal_cur;
    ++record_index;
  }
  data_total_ = record_index;
}

void TrafficAnalysis::PointToList() {
  cal_list_->clear();
  for (int data_index = 0; data_index < data_total_; data_index++) {
		if (!caldata_[data_index].valid) continue;
    cal_list_->push_back(caldata_[data_index]);
  }
  delete []caldata_;
}

void TrafficAnalysis::AnalysisProcess() {
  int line_total = data_total_;
  CalData* content = caldata_;
  Headway(line_total, content);
  Filter(line_total, content);
  LocalAvg(line_total, content);
  StopAdjust(line_total, content);
  Congestion(line_total, content);
  Level(line_total, content);
}


void TrafficAnalysis::Headway(int total, CalData* content) {
	content[0].headway = 0;
	for (int line = 1; line < total; line++) {
		content[line].headway = content[line].timesec - content[line-1].timesec;
    //printf("h : %d %d %d\n", 
    //        content[line].headway, content[line].timesec, content[line-1].timesec);	
  }
}


void TrafficAnalysis::Filter(int total, CalData* content) {
	// filter 0 headway
	for (int line = 0; line < total; line++) {
		if (content[line].headway <= 0) content[line].valid = false;
			//content[line].timesec, content[line].headway);
	}
}

void TrafficAnalysis::LocalAvg(int total, CalData* content) {
	float average;
	int count, sum;
	int headway_cur;
	for (int line = 0; line < total; line++) {
		content[line].localavg = content[line].headway;
		if (!content[line].valid) continue;
		headway_cur = content[line].headway;
		count = 0; sum = 0;
		for (int front = line - 1; count < 5; front--) {
			if (front < 0) break;
			//printf("%d %d %d\n", line, front, count);
			if (!content[front].valid) continue;
			if (headway_cur < content[front].headway) continue;
			sum += content[front].headway;
			++count;
		}

		for (int before = line + 1; count <= 10; before++) {
			if (before >= total) break;
			if (!content[before].valid) continue;
			if (headway_cur < content[before].headway) continue;
			sum += content[before].headway;
			++count;
		}
		if (count) {
			average = (float)sum / (float)count;
			content[line].localavg = (int)average;
		}
	}
}

void TrafficAnalysis::StopAdjust(int total, CalData* content) {
	for (int line = 0; line < total; line++) {
	  if (!content[line].valid) continue;
		if (content[line].headway > content[line].localavg * 5) {
			content[line].headway = content[line].localavg;
		}
		//content[line].timesec, content[line].headway);
	}
}

void TrafficAnalysis::Congestion(int total, CalData* content) {
	float congestion;
	int count, sum;
	int headway_cur;
	for (int line = 0; line < total; line++) {
		if (!content[line].valid) continue;
		headway_cur = content[line].headway;
		count = 0; sum = 0;
		for (int front = line; count < 10; front--) {
			if (front < 0) break;
			//printf("%d %d %d\n", line, front, count);
			if (!content[front].valid) continue;
			sum += content[front].headway;
			++count;
		}
		for (int before = line + 1; count <= 20; before++) {
			if (before >= total) break;
			if (!content[before].valid) continue;
			sum += content[before].headway;
			++count;
		}
		if (count) {
			congestion = (float)sum / (float)count;
			content[line].congestion = (int)congestion;
		}
	}
}

void TrafficAnalysis::Level(int total, CalData* content) {
  for (int line = 0; line < total; line++) {
	int headway_avg = content[line].congestion;
	content[line].level = 1;
	if (headway_avg <= 5) {
	  content[line].level = 5;
	} else if (headway_avg > 5 && headway_avg <= 10) {
	  content[line].level = 4;
	}
	else if (headway_avg > 10 && headway_avg <= 15) {
	  content[line].level = 3;
	}
	else if (headway_avg > 15 && headway_avg <= 30) {
	  content[line].level = 2;
	}
	else if (headway_avg > 30 ) {
	  content[line].level = 1;
	}
	//content[line].timesec, content[line].headway);
  }
}
//---------------------------------------------------------------------------
