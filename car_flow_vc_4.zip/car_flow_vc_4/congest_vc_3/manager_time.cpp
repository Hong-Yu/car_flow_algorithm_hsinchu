#include "manager_time.h"

#include <stdio.h>
#include <time.h>

int HourToSec(char* time) {
	int hour, minute, sec;
	sscanf(time, "%d:%d:%d", &hour, &minute, &sec);
    if (hour == 12) hour = 0;
	return hour * 3600 + minute * 60 + sec;
}

void SecToHour(int input_sec, char* time) {
	int hour, minute, sec;
	hour = input_sec % 3600;
	input_sec -= hour * 3600;
	minute = input_sec % 60;
	input_sec -= minute * 60;
	sec = input_sec;
	sprintf(time, "%d:%d:%d", hour, minute, sec);
}

int TimeDifference(char* start, char* end) {
	int diff;
	diff = HourToSec(end) - HourToSec(start);
	return diff;
}

std::string TableNameToday() {
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  char c_name[14]; 
  //printf("%d %02d %d\n", timeinfo->tm_year, timeinfo->tm_mon + 1, timeinfo->tm_mday);
  sprintf(c_name, "CarRecord%02d%02d", timeinfo->tm_mon + 1, timeinfo->tm_mday);
  std::string name = c_name;
  return name;
}

int StartTimeRevise(int start, int period) {
  int quotient = start / period;
  return quotient * period;
}