#include "travel_analysis.h"

#include "math.h"
using namespace std;
// TravelAnalysis public member -----------------------------------------------
TravelAnalysis::TravelAnalysis() {
  travel_time_avg_ = 0;
}

TravelAnalysis::~TravelAnalysis() {
}

void TravelAnalysis::Analysis() {
  travel_time_avg_ = default_time_;
  //printf("Travel time analysis -- src : %d des : %d\n", start_list_->size(), end_list_->size());
  if (start_list_->size() == 0 || end_list_->size() == 0) return;
  // 1. prepare result container.
  travel_time_.clear();
  // 2. reverse start camera
  start_list_->reverse();
  CompareTravelTime();
  if (travel_time_.size() <= 5) {
    //printf("Insufficient data\n");
    travel_time_avg_ = default_time_;
    return;
  }
  LowValue();
  AverageTravelTime();
  //travel_time_.push_back(48);
  //StandardDeviation();
  Show();
}

// TravelAnalysis private member ---------------------------------------------
void TravelAnalysis::CompareTravelTime() {
  int car_count = 0;
  int interval;
  list<InputMDB>::iterator iter_star, iter_end;
  for (iter_end = end_list_->begin(); iter_end != end_list_->end(); ++iter_end) {
    if (car_count >= 25) break;
    for (iter_star = start_list_->begin(); iter_star != start_list_->end(); ++iter_star) {
      if (!strcmp(iter_end->plate_number, iter_star->plate_number)) {

        //printf("!!!! %s %s %d %d\n", iter_end->plate_number, iter_star->plate_number,
        //                             iter_end->log_date, iter_star->log_date);
        if (iter_end->log_date < iter_star->log_date) continue;
        interval = iter_end->log_date - iter_star->log_date;
        interval = abs(interval) / 60;
        travel_time_.push_back(interval);
        ++car_count;
        break;
      }
    }
  }
}

void TravelAnalysis::LowValue() {
  int count = 0; 
  travel_time_.sort();
  std::list<int>::iterator iter_travel_time;
  for (iter_travel_time = travel_time_.begin(); iter_travel_time != travel_time_.end(); ) {
    if (count > 10) {
      iter_travel_time = travel_time_.erase(iter_travel_time);
      continue;
    }
    ++iter_travel_time;
    ++count;
  }
}

void TravelAnalysis::StandardDeviation() {
  int count = 0;
  std::list<int>::iterator iter_travel_time;
  double deviation, std_dev, dev_sum;
  double average = (double)travel_time_avg_;
  int total = travel_time_.size();
  for (iter_travel_time = travel_time_.begin(); 
       iter_travel_time != travel_time_.end(); ++iter_travel_time) {
    deviation = fabs(*iter_travel_time - average);
    printf("%d %d %lf\n", count++, *iter_travel_time, deviation);
    dev_sum += deviation * deviation;
  }
  std_dev = sqrt(dev_sum/total);
  /*
  std_dev *= 3.0;
  for (iter_travel_time = travel_time_.begin(); 
       iter_travel_time != travel_time_.end(); ++iter_travel_time) {
    deviation = fabs(*iter_travel_time - average);
    if (deviation < std_dev) {
      ++iter_travel_time;
      continue;
    }
    travel_time_.erase(iter_travel_time);
  }
  */
}

void TravelAnalysis::AverageTravelTime() {
  
  int sum = 0;
  int total = travel_time_.size();
  std::list<int>::iterator iter_travel_time;
  for (iter_travel_time = travel_time_.begin(); 
       iter_travel_time != travel_time_.end(); ++iter_travel_time) {
    sum += *iter_travel_time;
  }
  travel_time_avg_ = sum / total + 1;
  if (total < 5) 
    travel_time_avg_ = default_time_;
  
  // Smallest Only
  iter_travel_time = travel_time_.begin();
  travel_time_avg_ = *iter_travel_time;

}


void TravelAnalysis::Show() {
  int index = 0;
  std::list<int>::iterator iter_travel_time;
  for (iter_travel_time = travel_time_.begin(); 
       iter_travel_time != travel_time_.end(); ++iter_travel_time) {
    //printf("%d %d\n", index++, *iter_travel_time);
  }
  printf("ToT Average : %d\n", travel_time_avg_);
}
