#include "data_display.h"

#include <stdio.h>

void DataListDisplay::Show(std::list<InputDB> &input_list) {
  std::list<InputDB>::iterator input_iter;
  for (input_iter=input_list.begin(); input_iter!=input_list.end(); ++input_iter) {
    printf("%d %s %s %d\n",
           input_iter->serial_no, input_iter->log_date, input_iter->plate_number,
           input_iter->region_code);
  }
}

void DataListDisplay::Show(std::list<InputMDB> &input_list) {
  std::list<InputMDB>::iterator input_iter;
  for (input_iter=input_list.begin(); input_iter!=input_list.end(); ++input_iter) {
    printf("%d %d %s %d\n",
           input_iter->serial_no, input_iter->log_date, input_iter->plate_number,
           input_iter->region_code);
  }
}

void DataListDisplay::write(std::list<InputMDB> &input_list) {
  FILE* fptr = fopen("temp/show.txt","w");
  std::list<InputMDB>::iterator input_iter;
  for (input_iter=input_list.begin(); input_iter!=input_list.end(); ++input_iter) {
    fprintf(fptr, "%d %d %s %d\n",
           input_iter->serial_no, input_iter->log_date, input_iter->plate_number,
           input_iter->region_code);
  }
  fclose(fptr);
}

void DataListDisplay::Show(std::list<CalData> &cal_list) {
  std::list<CalData>::iterator cal_iter;
  for (cal_iter=cal_list.begin(); cal_iter!=cal_list.end(); ++cal_iter) {
    printf("%d %s %d :: %s %d %d %d %d %d\n",
           cal_iter->id, cal_iter->plate, cal_iter->region, 
           cal_iter->valid ? "true" : "false", cal_iter->timesec, 
           cal_iter->headway, cal_iter->localavg, cal_iter->congestion, 
           cal_iter->level);
  }
}

void DataListDisplay::Show(std::list<OutputCongestDB*> &out_list) {
  int index = 0;
  std::list<OutputCongestDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    printf("%d %d %s %s %d\n",
           index++, (*output_iter)->equid, (*output_iter)->data_time,
           (*output_iter)->create_time, (*output_iter)->val);
  }
}