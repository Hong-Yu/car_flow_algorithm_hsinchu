#ifndef DATABASE_INSERT_H_
#define DATABASE_INSERT_H_
#include <SQLAPI.h>
#include <list>
#include "data_member.h"

class DatabaseInsert {
 public:
   DatabaseInsert(SAConnection* con_output);
   ~DatabaseInsert();
   void Insert(std::list<OutputTravelDB*>& output_list);
   void Insert(std::list<OutputCongestDB*>& output_list);
   void Insert(std::list<OutputCountDB*>& output_list);
 private:
    SAConnection* con_output_;
};

#endif // DATABASE_INSERT_H_