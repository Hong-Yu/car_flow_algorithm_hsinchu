#ifndef TRAVEL_ANALYSIS_H_
#define TRAVEL_ANALYSIS_H_
#include <list>
#include <vector>
#include "data_member.h"

class TravelAnalysis {
public:
  TravelAnalysis();
  ~TravelAnalysis();
  void set_default_time(int default_time) {
    default_time_ = default_time;
  }
  void set_start_list(std::list<InputMDB>& start_list) {
    start_list_ = &start_list;
  }
  void set_end_list(std::list<InputMDB>& end_list) {
    end_list_ = &end_list;
  }
  void Analysis();
  int get_travel_time() {return travel_time_avg_;}
private:
  void CompareTravelTime();
  void LowValue();
  void StandardDeviation();
  void AverageTravelTime();
  void Show();
  std::list<InputMDB>* start_list_, *end_list_;
  std::list<int> travel_time_;
  int travel_time_avg_;
  int default_time_;
};
#endif //TRAVEL_ANALYSIS_H_