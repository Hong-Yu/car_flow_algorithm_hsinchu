#ifndef SUB_PROCESS_TRAVEL_H_
#define SUB_PROCESS_TRAVEL_H_
#include <list>
#include "data_member.h"

void TravelProcess(int road_id, 
                   std::vector<int> camera_start, 
                   std::vector<int> camera_end, 
                   int default_time, 
                   int time_start, int time_inteval, int time_period, 
                   std::list<OutputTravelDB*> &output_list_congest);
#endif // SUB_PROCESS_TRAVEL_H_