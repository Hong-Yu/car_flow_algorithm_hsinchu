#include "database.h"

#include <stdio.h>
#include "stopwatch.h"
#include "manager_time.h" // Today table name
// Database public member -----------------------------------------------------
Database::Database() {
  input_info = new ConnectInfo;
  output_info = new ConnectInfo;
  device_info = new ConnectInfo;
  con_input = new SAConnection;
  con_output = new SAConnection;
  con_device = new SAConnection;
  is_success_ = true;
  car_total_ = 0;
  car_data_ = NULL;
  Initialize();
}
Database::~Database() {
  delete input_info, output_info, device_info;
  //delete con_input, con_output; // trigger bad point
  if (car_data_ != NULL)
    delete[] car_data_;
  printf("Free --- RecordCar\n");
}

void Database::Connect() {
  is_success_ = true;
  Stopwatch stopwatch;
  //stopwatch.Decrease(5);
  ConnectTODatabase();
  //TableDelete();
  //stopwatch.Decrease(1);
  TableTest();
  //TableCopy();
  //getchar();
}

void Database::Disconnect() {
  DisconnectTODatabase();
}

void Database::Read(int &id_last, std::list<InputDB>& input_list) {
  printf("Maeda: CarRecord total :%d\n", car_total_);
  car_data_ = new InputDB[car_total_ + 10000];
  ReadCarRecord();
  //ReadDataBase(input_total, inputdb);
  //ReadTextDataBase(input_total, inputdb);
  // Put new data from stack array to std list.
  input_list.clear();
  for (int line = 0; line < car_total_; line++) {
    if (id_last >= car_data_[line].serial_no) continue; 
    input_list.push_back(car_data_[line]);
  }
  // Check new data are available.
  if (input_list.empty()) {
    printf("No new input data, program sleep.\n");
    return;
  }
  // Fine a last id of new input data list.
  int id_max_new = car_data_[car_total_ - 1].serial_no;
  printf("Start id: %d num of new data: %d Last id of new data %d\n", 
    id_last, input_list.size(), id_max_new);
    id_last = id_max_new;
}

// Database private member -----------------------------------------------------
void Database::Initialize() {
  ReadInfomation();
}

void Database::ReadInfomation() {
  char* filename = "user/database.txt";
  FILE *fptr = fopen(filename, "r");
  if (fptr == NULL) { 
    printf("User control file %s lack! system stop.\n", filename);
    getchar();
  } 
  char sread[15][200];
  for (int line_index = 0; line_index < 15; line_index++) {
    fgets(sread[line_index], 200, fptr);
    //printf("%s", sread[line_index]);
  }
  fclose(fptr);
  sscanf(sread[1], "%*[^':']:%s", input_info->server_name);
  sscanf(sread[2], "%*[^':']:%s", input_info->database_name);
  sscanf(sread[3], "%*[^':']:%s", input_info->user_name);
  sscanf(sread[4], "%*[^':']:%s", input_info->user_password);
  printf("Input -- Database name : %s\n", input_info->server_name);
  printf("Input -- Server   name : %s\n", input_info->database_name);
  printf("Input -- User     name : %s\n", input_info->user_name);
  printf("Input -- User Password : %s\n", input_info->user_password);
  sscanf(sread[6], "%*[^':']:%s", device_info->server_name);
  sscanf(sread[7], "%*[^':']:%s", device_info->database_name);
  sscanf(sread[8], "%*[^':']:%s", device_info->user_name);
  sscanf(sread[9], "%*[^':']:%s", device_info->user_password);
  printf("Device -- Database name : %s\n", device_info->server_name);
  printf("Device -- Server   name : %s\n", device_info->database_name);
  printf("Device -- User     name : %s\n", device_info->user_name);
  printf("Device -- User Password : %s\n", device_info->user_password);
  sscanf(sread[11], "%*[^':']:%s", output_info->server_name);
  sscanf(sread[12], "%*[^':']:%s", output_info->database_name);
  sscanf(sread[13], "%*[^':']:%s", output_info->user_name);
  sscanf(sread[14], "%*[^':']:%s", output_info->user_password);
  printf("Output -- Database name : %s\n", output_info->server_name);
  printf("Output -- Server   name : %s\n", output_info->database_name);
  printf("Output -- User     name : %s\n", output_info->user_name);
  printf("Output -- User Password : %s\n", output_info->user_password);
}

void Database::ConnectTODatabase() {
  char sql_name[100];
  sprintf(sql_name, "%s\@%s", input_info->server_name, 
                              input_info->database_name);
  try {
    con_input->Connect(sql_name,
                       input_info->user_name,
                       input_info->user_password,
                       SA_SQLServer_Client);
    printf("Input database connect successful.\n");
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
  sprintf(sql_name, "%s\@%s", device_info->server_name, 
                              device_info->database_name);
  try {
    con_device->Connect(sql_name,
                       device_info->user_name,
                       device_info->user_password,
                       SA_SQLServer_Client);
    printf("Device database connect successful.\n");
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
  sprintf(sql_name, "%s\@%s", output_info->server_name, 
                              output_info->database_name);
  try {
    con_output->Connect(sql_name,
                       output_info->user_name,
                       output_info->user_password,
                       SA_SQLServer_Client);
    printf("Output database connect successful.\n");
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
}

void Database::DisconnectTODatabase() {
    try {
    con_input->Disconnect();
    printf("Input database disconnect.\n");
    con_device->Disconnect();
    printf("Device database disconnect.\n");
    con_output->Disconnect();
    printf("Output database disconnect.\n");
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
}

void Database::TableTest() {
  SACommand cmd;
  // 1. Test CarRecord
  cmd.setConnection(con_input);
  car_total_ = TableCount(cmd, TableNameToday().c_str(), "SerialNo");
  // 2. Test TrafficInfo
  cmd.setConnection(con_device);
  TableCount(cmd, "TrafficInfo", "id");
  // 3. Test Travel
  TableCount(cmd, "Travel", "id");
}

void Database::TableDelete() {
  SACommand cmd;
  try {
    cmd.setConnection(con_output);
    cmd.setCommandText("Delete from TravelTime");
    cmd.Execute();
    cmd.setCommandText("Delete from TrafficCar");
    cmd.Execute();
    cmd.setCommandText("Delete from TrafficCount");
    cmd.Execute();
    printf("Delete table\n");
  } 
  catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
  getchar();
}

int Database::TableCount(SACommand& cmd, const char* table_name, char* mark) {
  int record_count = 0;
  char command_text[100];
  sprintf(command_text, "Select %s from %s", mark, table_name);
  try {
    cmd.setCommandText(command_text);
    cmd.Execute();
    while (cmd.FetchNext()) { ++record_count; }
    printf("Table \'%s\' count : %d\n",table_name, record_count);
  } 
  catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    printf("Lacking table : %s\n", table_name);
    is_success_ = false;
  }
  return record_count;
}

void Database::TableCopy() {
  SACommand cmd, cmd_insert;
  cmd.setConnection(con_input);
  cmd_insert.setConnection(con_input);
  int record_count = 0;
  char command_text[200];
  char text_insert[200];
  char* col_name_a = "SerialNo, Date_Year, Date_Month, Date_Day, ";
  char* col_name_b = "LogDate, LogTime, PlateNumber, RegionCode, Time_Hour, ";
  char* col_name_c = "Time_Min, Time_Sec";
  char* value_name = "values (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11)";
  sprintf(command_text, "Select %s%s%s from CarRecord0624", col_name_a, col_name_b,
                                                            col_name_c);
  sprintf(text_insert, "Insert into CarRecord0825 (%s%s%s) %s", col_name_a, col_name_b,
                                                              col_name_c, value_name);
  printf("%s\n", text_insert);
  try {
    cmd.setCommandText(command_text);
    cmd.Execute();
    cmd_insert.setCommandText(text_insert);
    while (cmd.FetchNext()) { 
      cmd_insert.Param(1).setAsLong() = cmd.Field("SerialNo").asLong();
      cmd_insert.Param(2).setAsLong() = cmd.Field("Date_Year").asLong();
      cmd_insert.Param(3).setAsLong() = cmd.Field("Date_Month").asLong();
      cmd_insert.Param(4).setAsLong() = cmd.Field("Date_Day").asLong();
      cmd_insert.Param(5).setAsDateTime() = cmd.Field("LogDate").asDateTime();
      cmd_insert.Param(6).setAsDateTime() = cmd.Field("LogTime").asDateTime();
      cmd_insert.Param(7).setAsString() = cmd.Field("PlateNumber").asString();
      cmd_insert.Param(8).setAsLong() = cmd.Field("RegionCode").asLong();
      cmd_insert.Param(9).setAsLong() = cmd.Field("Time_Hour").asLong();
      cmd_insert.Param(10).setAsLong() = cmd.Field("Time_Min").asLong();
      cmd_insert.Param(11).setAsLong() = cmd.Field("Time_Sec").asLong();
      cmd_insert.Execute();
      ++record_count; 
    }
    printf("Table copy done. %d\n", record_count);
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
  getchar();
}

void Database::ReadCarRecord() {
  SACommand cmd_select;
  cmd_select.setConnection(con_input);
  char text_select[200];
  char* col_name_a = "SerialNo, LogDate, PlateNumber, RegionCode";
  sprintf(text_select, "Select %s from %s", col_name_a, TableNameToday().c_str());
  try {
    cmd_select.setCommandText(text_select);
    cmd_select.Execute();
    InputDB* record;
    int record_index = 0;
    std::string logdate, platenumber;
    while (cmd_select.FetchNext()) { 
      record = &car_data_[record_index];
      record->serial_no = cmd_select.Field("SerialNo").asLong();
      record->region_code = cmd_select.Field("RegionCode").asLong();
      logdate = cmd_select.Field("LogDate").asString(); // Attention
      platenumber = cmd_select.Field("PlateNumber").asString();
      strcpy(record->log_date, logdate.c_str());
      strcpy(record->plate_number, platenumber.c_str());
      ++record_index;
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
}