#ifndef MANAGER_TIME_H_
#define MANAGER_TIME_H_
#include <string>

int HourToSec(char* hour);
void SecToHour(int sec, char* time);
int TimeDifference(char* start, char* end);
std::string TableNameToday();
int StartTimeRevise(int start, int period);
#endif // MANAGER_TIME_H_