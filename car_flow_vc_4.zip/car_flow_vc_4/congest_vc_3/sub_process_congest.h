#ifndef SUB_PROCESS_CONGEST_H_
#define SUB_PROCESS_CONGEST_H_

void CongestionProcess(int camera_id, int camera_num, int time_start, int time_inteval,
                       int time_period, 
                       std::list<OutputCongestDB*> &output_list_congest);
void CarCountProcess(int camera_id, int camera_num, int time_start, int time_inteval,
                       int time_period, 
                       std::list<OutputCountDB*> &output_list_congest);
#endif // SUB_PROCESS_CONGEST_H_
