#include "database_insert.h"

DatabaseInsert::DatabaseInsert(SAConnection* con_output) {
  con_output_ = con_output;
}

DatabaseInsert::~DatabaseInsert() {
}

void DatabaseInsert::Insert(std::list<OutputTravelDB*>& output_list) {
  SACommand cmd_insert;
  cmd_insert.setConnection(con_output_);
  char* table_name = "TravelTime";
  char* col_name_a = "TravelID, CreateTime, ";
  char* col_name_b = "DateTime, dTime";
  char* value_name = "values (:1, :2, :3, :4)";
  char text_insert[200];
  sprintf(text_insert, "Insert into %s (%s%s) %s", 
                        table_name, col_name_a, col_name_b, value_name);
  cmd_insert.setCommandText(text_insert);
  try {
    std::list<OutputTravelDB*>::iterator output_iter;
    for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
      cmd_insert.Param(1).setAsLong() = (*output_iter)->travel_id;
      cmd_insert.Param(2).setAsDateTime() = (*output_iter)->create_time_dt;
      cmd_insert.Param(3).setAsDateTime() = (*output_iter)->data_time_dt;
      cmd_insert.Param(4).setAsLong() = (*output_iter)->d_time;
      cmd_insert.Execute();
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    getchar();
  }
}

void DatabaseInsert::Insert(std::list<OutputCongestDB*>& output_list) {
  SACommand cmd_insert;
  cmd_insert.setConnection(con_output_);
  char* table_name = "TrafficCar";
  char* col_name_a = "TrafficID, EquID, CreateTime, ";
  char* col_name_b = "DateTime, Val";
  char* value_name = "values (:1, :2, :3, :4, :5)";
  char text_insert[200];
  sprintf(text_insert, "Insert into %s (%s%s) %s", 
                        table_name, col_name_a, col_name_b, value_name);
  cmd_insert.setCommandText(text_insert);
  try {
    std::list<OutputCongestDB*>::iterator output_iter;
    for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
      cmd_insert.Param(1).setAsLong() = (*output_iter)->traffic_id;
      cmd_insert.Param(2).setAsLong() = (*output_iter)->equid;
      cmd_insert.Param(3).setAsDateTime() = (*output_iter)->create_time_dt;
      cmd_insert.Param(4).setAsDateTime() = (*output_iter)->data_time_dt;
      cmd_insert.Param(5).setAsLong() = (*output_iter)->val;
      cmd_insert.Execute();
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    getchar();
  }
}

void DatabaseInsert::Insert(std::list<OutputCountDB*>& output_list) {
  SACommand cmd_insert;
  cmd_insert.setConnection(con_output_);
  char* table_name = "TrafficCount";
  char* col_name_a = "TrafficID, EquID, CreateTime, ";
  char* col_name_b = "DateTime, Val";
  char* value_name = "values (:1, :2, :3, :4, :5)";
  char text_insert[200];
  sprintf(text_insert, "Insert into %s (%s%s) %s", 
                        table_name, col_name_a, col_name_b, value_name);
  cmd_insert.setCommandText(text_insert);
  try {
    std::list<OutputCountDB*>::iterator output_iter;
    for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
      cmd_insert.Param(1).setAsLong() = (*output_iter)->traffic_id;
      cmd_insert.Param(2).setAsLong() = (*output_iter)->equid;
      cmd_insert.Param(3).setAsDateTime() = (*output_iter)->create_time_dt;
      cmd_insert.Param(4).setAsDateTime() = (*output_iter)->data_time_dt;
      cmd_insert.Param(5).setAsLong() = (*output_iter)->val;
      cmd_insert.Execute();
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    getchar();
  }
}


/*
void WriteDataBaseTravelTime(std::list<OutputTravelDB*>& output_list) {
  DataModule2->TravelTimeTable->Edit();
  DataModule2->TravelTimeTable->Insert();
  std::list<OutputTravelDB*>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->TravelTimeTable->Insert();
    DataModule2->TravelTimeTable->FieldByName("TravelID")->AsInteger = output_iter->travel_id;
    DataModule2->TravelTimeTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->TravelTimeTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->TravelTimeTable->FieldByName("dTime")->AsInteger = output_iter->d_time;
    DataModule2->TravelTimeTable->Post();
  }
}

void WriteDataBaseCongest(std::list<OutputCongestDB*>& output_list) {
  DataModule2->CongestionTable->Edit();
  DataModule2->CongestionTable->Insert();
  std::list<OutputCongestDB*>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->CongestionTable->Insert();
    DataModule2->CongestionTable->FieldByName("TrafficID")->AsInteger = output_iter->traffic_id;
    DataModule2->CongestionTable->FieldByName("EquID")->AsInteger = output_iter->equid;
    DataModule2->CongestionTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->CongestionTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->CongestionTable->FieldByName("Val")->AsInteger = output_iter->val;
    DataModule2->CongestionTable->Post();
  }
}
void WriteDataBaseCarCount(std::list<OutputCountDB>& output_list) {
  DataModule2->CarCountTable->Edit();
  DataModule2->CarCountTable->Insert();
  std::list<OutputCountDB>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->CarCountTable->Insert();
    DataModule2->CarCountTable->FieldByName("TrafficID")->AsInteger = output_iter->traffic_id;
    DataModule2->CarCountTable->FieldByName("EquID")->AsInteger = output_iter->equid;
    DataModule2->CarCountTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->CarCountTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->CarCountTable->FieldByName("Val")->AsInteger = output_iter->val;
    DataModule2->CarCountTable->Post();
  }
}

void Database::TableCopy() {
  SACommand cmd, cmd_insert;
  cmd.setConnection(con_input);
  cmd_insert.setConnection(con_input);
  int record_count = 0;
  char command_text[200];
  char text_insert[200];
  char* col_name_a = "SerialNo, Date_Year, Date_Month, Date_Day, ";
  char* col_name_b = "LogDate, LogTime, PlateNumber, RegionCode, Time_Hour, ";
  char* col_name_c = "Time_Min, Time_Sec";
  char* value_name = "values (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11)";
  sprintf(command_text, "Select %s%s%s from CarRecord0115", col_name_a, col_name_b,
                                                            col_name_c);
  sprintf(text_insert, "Insert into CarRecord0206 (%s%s%s) %s", col_name_a, col_name_b,
                                                              col_name_c, value_name);
  printf("%s\n", text_insert);
  try {
    cmd.setCommandText(command_text);
    cmd.Execute();
    cmd_insert.setCommandText(text_insert);
    while (cmd.FetchNext()) { 
      cmd_insert.Param(1).setAsLong() = cmd.Field("SerialNo").asLong();
      cmd_insert.Param(2).setAsLong() = cmd.Field("Date_Year").asLong();
      cmd_insert.Param(3).setAsLong() = cmd.Field("Date_Month").asLong();
      cmd_insert.Param(4).setAsLong() = cmd.Field("Date_Day").asLong();
      cmd_insert.Param(5).setAsDateTime() = cmd.Field("LogDate").asDateTime();
      cmd_insert.Param(6).setAsDateTime() = cmd.Field("LogTime").asDateTime();
      cmd_insert.Param(7).setAsString() = cmd.Field("PlateNumber").asString();
      cmd_insert.Param(8).setAsLong() = cmd.Field("RegionCode").asLong();
      cmd_insert.Param(9).setAsLong() = cmd.Field("Time_Hour").asLong();
      cmd_insert.Param(10).setAsLong() = cmd.Field("Time_Min").asLong();
      cmd_insert.Param(11).setAsLong() = cmd.Field("Time_Sec").asLong();
      cmd_insert.Execute();
      ++record_count; 
    }
    printf("Table copy done. %d\n", record_count);
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    is_success_ = false;
  }
  getchar();
}
*/