#ifndef STOPWATCH_H_
#define STOPWATCH_H_
class Stopwatch {
 public:
   void Decrease(int sec);
 private:
};

#endif // STOPWATCH_H_