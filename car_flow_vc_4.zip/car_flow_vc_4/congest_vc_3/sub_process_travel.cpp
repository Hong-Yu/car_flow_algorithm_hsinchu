#include <stdio.h>

#include "data_transfer.h"
#include "data_display.h"
#include "extract_interval_data.h"
#include "manager_time.h"
#include "single_camera_io.h"
#include "travel_analysis.h"

void TravelProcess(int road_id, 
                   std::vector<int> camera_start, 
                   std::vector<int> camera_end, 
                   int default_time, 
                   int time_start, int time_inteval, int time_period, 
                   std::list<OutputTravelDB*> &output_list_congest) {
  printf("Travel time --- %2d %2d --- %d %d\n", 
         camera_start[0], camera_end[0], road_id, default_time);
  // 1. Check time interval is bigger than period.
  if (time_inteval < time_period) return;
  // 2. Read specific camera data.
  std::list<InputMDB> scamr_list_start, scamr_list_end, interval_list;
  SingleCameraIO scamr_start, scamr_end;
  scamr_start.set_list(scamr_list_start);
  scamr_start.ReadSingleCameraData(camera_start[0]);
  scamr_end.set_list(scamr_list_end);
  scamr_end.ReadSingleCameraData(camera_end[0]);
  DataListDisplay display;
  //display.Show(scamr_list_start);
  //display.Show(scamr_list_end);
 // getchar(); 
  // 3. Set up travel time analysis process
  TravelAnalysis analysis;
  analysis.set_start_list(scamr_list_start);
   analysis.set_default_time(default_time);
  // 4. Set up data transfer process.
  DataTransfer transfer;
  // 6. Set up Extract interval data process.
  ExtractIntervalData extract;
  extract.set_raw_list(scamr_list_end);
  extract.set_interval_list(interval_list);
  int time_end = time_start + time_inteval;
  extract.Extract(time_end);

  
  printf("Extract ------ \n");
  // 7. Revise start time to be divided with no remainder.
  time_start = StartTimeRevise(time_start, time_period);
  for (int time_index = time_start + time_period; time_index < time_end;
       time_index+=time_period) {
         //printf("maeda : %d %d %d\n", time_index, time_start, time_total);
    // 1. Extract interval data 
    extract.Extract(time_index);
    // 2. Put interval list to analysis process
    analysis.set_end_list(interval_list);
    // 3. Analysis interval data and form congestion values.
    analysis.Analysis();
    int travel_time = analysis.get_travel_time();
    // 4. Insert a result to output list. 
    transfer.InsertTravelTime(time_index, road_id, travel_time,
                              output_list_congest);
    //display.Show(output_list_congest);
    //getchar();
  }
  
}
