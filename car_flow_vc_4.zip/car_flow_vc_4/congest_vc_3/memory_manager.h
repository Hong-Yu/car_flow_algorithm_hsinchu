#ifndef MEMORY_MANAGER_H_
#define MEMORY_MANAGER_H_
#include <list>
#include "data_member.h"

class MemoryManager {
public:
  void deallocate(std::list<OutputTravelDB*> &out_list);
  void deallocate(std::list<OutputCongestDB*> &out_list);
  void deallocate(std::list<OutputCountDB*> &out_list);
private:
};

#endif // MEMORY_MANAGER_H_