#ifndef DATABASE_CONNECT_H_
#define DATABASE_CONNECT_H_
#include <SQLAPI.h>
#include <list>
#include "data_member.h"

struct ConnectInfo {
  char server_name[100];
  char database_name[100];
  char user_name[100];
  char user_password[100];
};

class Database {
public:
  Database();
  ~Database();
  void Connect();
  void Disconnect();
  void Read(int &id_last, std::list<InputDB>& input_list);
  SAConnection* get_con_device() { return con_device; }
  SAConnection* get_con_output() { return con_output; }
  bool Status() { return is_success_; }
private:
  void Initialize();
  void ReadInfomation();
  void ConnectTODatabase();
  void DisconnectTODatabase();
  void TableTest();
  void TableDelete();
  int TableCount(SACommand& cmd, const char* name, char* mark);
  void TableCopy();
 
  void ReadCarRecord();
  ConnectInfo* input_info;
  ConnectInfo* output_info;
  ConnectInfo* device_info;
  SAConnection* con_input, *con_output, *con_device;
  bool is_success_;
  int car_total_;
  InputDB* car_data_;

};

#endif // DATABASE_CONNECT_H_