#ifndef DATA_MEMBER_H_
#define DATA_MEMBER_H_
#include <time.h>
#include <vector>
typedef struct tm DateTime;

typedef struct InputDB {
  int serial_no;
  char log_date[25];
  char plate_number[15];
  int region_code;
} InputDB;

typedef struct InputMDB {
  int serial_no;
  int log_date;
  char plate_number[15];
  int region_code;
} InputMDB;

typedef struct OutputTravelDB {
  int travel_id;
  char data_time[50];
  char create_time[50];
  DateTime data_time_dt;
  DateTime create_time_dt;
  int d_time;
} OutputTravelDB;

typedef struct OutputCongestDB {
  int traffic_id;
  int equid;
  char data_time[50];
  char create_time[50];
  DateTime data_time_dt;
  DateTime create_time_dt;
  int val;
} OutputCongestDB;

typedef struct OutputCountDB {
  int traffic_id;
  int equid;
  char data_time[50];
  char create_time[50];
  DateTime data_time_dt;
  DateTime create_time_dt;
  int val;
} OutputCountDB;

typedef struct CalData {
  // Inpute
  int id;
  char date[50];
  char plate[50];
  int region;
  // calculate
  bool valid;
  int timesec;
  int headway; //second
  int localavg;
  int congestion;
  int level;
}CalData;

typedef struct RoadDB {
  bool is_adequate;
  int id;
  int default_time;
  std::vector<int> camera_start;
  std::vector<int> camera_end;
}RoadDB;

/*
class CarData {
  public:
  int SerialNo;
  int Date_Year;
  int Date_Month;
  int Date_Day;
  char LogDate[50];
  char LogTime[50];
  char PlateNumber[20];
  int RegionCode;
  int Time_Hour;
  int Time_Min;
  int Time_Sec;
};

typedef struct LogData {
  int no;
  char license[KlengthMax];
  char day[KlengthMax];
  char hour[KlengthMax];
  int timesec;
  int headway; //second
  bool valid;
  int localavg;
  int congestion;
  int level;
}LogData;
*/

#endif //DATA_MEMBER_H_
