#include "read_road_info.h"

#include <stdio.h>
#include <string.h>

//#include "data_module.h"

using namespace std;
//ReadRoadInfo public member ------------------------------------------------
ReadRoadInfo::ReadRoadInfo(SAConnection* con_output){
  con_output_ = con_output;
  Initialize();
}

ReadRoadInfo::~ReadRoadInfo(){
  
  //vector<RoadDB*>::iterator iter;
  //for (iter = camera_id_vector_.begin(); iter != camera_id_vector_.end(); iter++) {
  //  delete *iter;
  //}
  
  //printf("Free --- road info\n");
}
//ReadRoadInfo private member -----------------------------------------------
void ReadRoadInfo::Initialize(){
  ReadDatabase();
}


void ReadRoadInfo::ReadDatabase() {
  SACommand cmd_select;
  cmd_select.setConnection(con_output_);
  char text_select[200];
  char* col_name_a = "id, PassCarID, DefaultTime";
  sprintf(text_select, "Select %s from Travel where PassCarID is not NULL", col_name_a);
  int record_index = 0;
  int id, default_time;
  //int camr[10];
  try {
    cmd_select.setCommandText(text_select);
    cmd_select.Execute();
    //InputDB* record;
    std::string pass_car_id;
    while (cmd_select.FetchNext()) { 
      RoadDB* road_data;
      id = cmd_select.Field("id").asLong();
      default_time = cmd_select.Field("DefaultTime").asLong();
      pass_car_id = cmd_select.Field("PassCarID").asString();
      printf("group assign %d %d\n", id, default_time);
      road_data = AssignCameraGroup(id, pass_car_id.c_str(), default_time);
      //sscanf(pass_car_id.c_str(), "%d,%d", &camr[0], &camr[1]);
      //sscanf(pass_car_id.c_str(), "%d,%d", &camr[0], &camr[1]);
      //road_data->PassCarID.push_back(camr[0]);
      //road_data->PassCarID.push_back(camr[1]);

      road_list_.push_back(road_data);
      ++record_index;
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    getchar();
  }
  printf("Total road %d\n", record_index);
  //getchar();
}


RoadDB* ReadRoadInfo::AssignCameraGroup(int id, const char* pass_car_id,
                                        int default_time) {
  bool is_group = true;
  char camera_set[2][100];
  int camera_start, camera_end;
  RoadDB* road_data = new RoadDB;
  road_data->is_adequate = false;
  road_data->id = id;
  road_data->default_time = default_time;
  if (strrchr(pass_car_id, ';') == NULL) is_group = false;
  if (is_group) {
    // 1. splite table column "PassCarID" into two string, the one contain
    // camera at start point anthor at end point.
    SplitToString(pass_car_id, ';', camera_set);
    // 2. Splite camera id set string into vector that contain int value of 
    // camera id.
    SplitToint(camera_set[0], ',', road_data->camera_start);
    SplitToint(camera_set[1], ',', road_data->camera_end);

  } else {
      sscanf(pass_car_id, "%d,%d", &camera_start, &camera_end);
      road_data->camera_start.push_back(camera_start);
      road_data->camera_end.push_back(camera_end);
  }
  if (road_data->camera_start.size() > 0 && 
      road_data->camera_end.size() > 0) road_data->is_adequate = true;

  return road_data;
}
/*
int main() {
  printf("Maeda: love is an open door!\n");
  const char* result = strrchr("love is an ;open door", ';');
  printf("char be found: %s\n ", (result == NULL) ? "false" : "true");
  const char* camara_id= "1,3,48;4";
  char res[2][100];
  SplitToString(camara_id, ';', res);
  printf("Result 1 : %s\n", res[0]);
  printf("Result 2 : %s\n", res[1]);
  std::vector<int> res_int[2];
  SplitToint(res[0], ',', res_int[0]);
  SplitToint(res[1], ',', res_int[1]);
  for (int vector_index = 0; vector_index < res_int[0].size(); ++vector_index) {
    printf("Result 1 : %d\n", res_int[0][vector_index]);
  }
  for (int vector_index = 0; vector_index < res_int[1].size(); ++vector_index) {
    printf("Result 2 : %d\n", res_int[1][vector_index]);
  }
  getchar();
}
*/
void ReadRoadInfo::SplitToString(const char* source, char separator, char (*res)[100]) {
  int source_index = 0;
  int result_index = 0;
  int section_index = 0;
  while(source[source_index] != '\0') {
    if (source[source_index] == separator) {
      res[section_index][result_index] = '\0';
      ++source_index; 
      ++section_index; 
      result_index = 0;
      continue;
    } 
    res[section_index][result_index] = source[source_index];
    ++source_index; 
    ++result_index;
  }
  res[section_index][result_index] = '\0';
}


void ReadRoadInfo::SplitToint(const char* source, char separator, std::vector<int>& result) {
  int source_index = 0;
  int result_index = 0;
  char value_char[100];
  int value_int;
  while(source[source_index] != '\0') {
    if (source[source_index] == separator) {
      sscanf(value_char, "%d", &value_int);
      result.push_back(value_int);
      ++source_index; 
      result_index = 0;
      continue;
    } 
    value_char[result_index] = source[source_index];
    ++source_index; 
    ++result_index;
  }
  sscanf(value_char, "%d", &value_int);
  result.push_back(value_int);
}

/*
typedef struct RoadDB {
  bool is_adequate;
  int id;
  int default_time;
  std::vector<int> camera_start;
  std::vector<int> camera_end;
}RoadDB;
*/

/*
void ReadRoadInfo::ReadDatabase() {
  // prepare container for reading
  int camr[10];
  // read information from file into vector.
  int record_total = DataModule2->RoadTable->RecordCount;
  DataModule2->RoadTable->Refresh();
  DataModule2->RoadTable->First();
  AnsiString pass_car_id;
  char rline[100];
  for (int record_index = 0; record_index < record_total; record_index++) {
    RoadDB* road_data = new RoadDB;
    road_data->id = DataModule2->RoadTable->FieldByName("id")->AsInteger;
    pass_car_id  = DataModule2->RoadTable->FieldByName("PassCarID")->AsString;
    sscanf(pass_car_id.c_str(), "%d,%d", &camr[0], &camr[1]);
    road_data->PassCarID.push_back(camr[0]);
    road_data->PassCarID.push_back(camr[1]);
    camera_id_vector_.push_back(*road_data);

    DataModule2->RoadTable->Next();
  }
}
*/
