#include "data_classification.h"

DataClassification::DataClassification() {
}

DataClassification::~DataClassification() {
}

int DataClassification::RawRemain(){
  return rawdata_->size();
}
void DataClassification::Classification(){
  std::list<InputDB>::iterator iter_raw, iter_class;
  iter_raw = rawdata_->begin();
  int region_current = iter_raw->region_code;
  for (iter_raw=rawdata_->begin(); iter_raw!=rawdata_->end();) {
    if (iter_raw->region_code != region_current) { 
      ++iter_raw;
      continue;
    }
    //printf("do %d\n", region_current);
    classdata_->push_back(*iter_raw);
    iter_raw = rawdata_->erase (iter_raw);
  }
  camera_id_ = region_current;
}