#ifndef DATA_CLASSIFICATION_H_
#define DATA_CLASSIFICATION_H_
#include <list>
#include "data_member.h"

class DataClassification {
 public:
  DataClassification();
  ~DataClassification();
  void set_rawdata(std::list<InputDB> &rawdata) { rawdata_ = &rawdata; }
  void set_classdata(std::list<InputDB> &classdata ) { classdata_ = &classdata; }
  int RawRemain();
  void Classification();
  int get_camera_id(){ return camera_id_; };
 private:
  std::list<InputDB>* rawdata_;
  std::list<InputDB>* classdata_;
  int camera_id_;
};

#endif //DATA_CLASSIFICATION_H_