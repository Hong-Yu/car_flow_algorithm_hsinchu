#ifndef MANAGER_IO_H_
#define MANAGER_IO_H_
#include <list>

int ReadIniInf();
void WriteIniInf(int pos_fal);
void ReadTextDataBase(int &line_total, InputDB* inputdb);
void ReadDataBase(int &line_total, InputDB* inputdb);

void DBToText();
// Result
void WriteDataBaseCongest(std::list<OutputCongestDB*>& output_list);
void WriteDataBaseCarCount(std::list<OutputCountDB>& output_list);
void WriteDataBaseTravelTime(std::list<OutputTravelDB*>& output_list);

// text
void WriteTextCongest(std::list<OutputCongestDB*> &out_list);
void WriteTextCarCount(std::list<OutputCountDB*> &out_list);
void WriteTextTravelTime(std::list<OutputTravelDB*> &out_list);

#endif // MANAGER_IO_H_
