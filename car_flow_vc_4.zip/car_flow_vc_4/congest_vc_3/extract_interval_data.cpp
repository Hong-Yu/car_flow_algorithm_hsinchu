#include "extract_interval_data.h"

using namespace std;
ExtractIntervalData::ExtractIntervalData() {
}
ExtractIntervalData::~ExtractIntervalData() {
}
void ExtractIntervalData::Extract(int time_start, int time_end) {
  interval_list_->clear();
  int time;
  list<InputMDB>::iterator iter_raw;
  for (iter_raw = raw_list_->begin(); iter_raw != raw_list_->end(); iter_raw++) {
    if (iter_raw->log_date < time_start) continue;
    if (iter_raw->log_date > time_end) continue;
    interval_list_->push_back(*iter_raw);
  }
}

void ExtractIntervalData::Extract(int time_end) {
  interval_list_->clear();
  int time;
  list<InputMDB>::iterator iter_raw;
  for (iter_raw = raw_list_->begin(); iter_raw != raw_list_->end(); iter_raw++) {
    if (iter_raw->log_date > time_end) continue;
    interval_list_->push_back(*iter_raw);
  }
}