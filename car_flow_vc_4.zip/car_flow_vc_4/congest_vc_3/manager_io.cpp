
#include <stdio.h>
#include <stdlib.h>

#include <list>
#include <string>

#include "data_member.h"
//#include "data_module.h"
#include "manager_time.h"

bool exist_test(const std::string name) {
  if (FILE *file = fopen(name.c_str(), "r")) {
    fclose(file);
    return true;
  } else {
    return false;
  }   
}

void ReadTextDataBase(int &line_total, InputDB* inputdb) {
  std::string table_name = "src/" + TableNameToday() + ".txt";
  FILE* fptr = fopen(table_name.c_str(), "r");
  if (fptr == NULL) {
    printf("Open file fail: %s\n", table_name.c_str());
		return;
	}
  InputDB* record;
  int line_num = 0;
  char rline[200];
  while (fgets(rline, 200, fptr) != NULL) {
	if (rline[0] == '\n') continue;
    record = &inputdb[line_num];
	sscanf(rline, "%d,%[^,],%[^,],%d", 
           &record->serial_no, record->log_date, record->plate_number,
           &record->region_code);
    /*
    printf("%d %s %s %d\n",
           record->serial_no, record->log_date, record->plate_number,
           record->region_code);
           */
	  line_num++;
  }
  fclose(fptr);
  line_total = line_num;
}

void WriteTextCongest(std::list<OutputCongestDB*> &out_list) {
  FILE* fptr = fopen("result/congestion.txt", "w");
  int index = 0;
  std::list<OutputCongestDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    fprintf(fptr, "%d %d %s %s %d\n",
           index++, (*output_iter)->equid, (*output_iter)->data_time,
           (*output_iter)->create_time, (*output_iter)->val);
  }
  fclose(fptr);
}

void WriteTextCarCount(std::list<OutputCountDB*> &out_list) {
  FILE* fptr = fopen("result/carcount.txt", "w");
  int index = 0;
  std::list<OutputCountDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    fprintf(fptr, "%d %d %s %s %d\n",
           index++, (*output_iter)->equid, (*output_iter)->data_time,
           (*output_iter)->create_time, (*output_iter)->val);
  }
  fclose(fptr);
}

void WriteTextTravelTime(std::list<OutputTravelDB*> &out_list) {
  FILE* fptr = fopen("result/traveltime.txt", "w");
  int index = 0;
  std::list<OutputTravelDB*>::iterator output_iter;
  for (output_iter=out_list.begin(); output_iter!=out_list.end(); ++output_iter) {
    fprintf(fptr, "%d %d %s %s %d\n",
           index++, (*output_iter)->travel_id, (*output_iter)->data_time,
           (*output_iter)->create_time, (*output_iter)->d_time);
  }
  fclose(fptr);
}
/*
void ReadDataBase(int &line_total, InputDB* inputdb) {
  //int record_total = DBM->CarRecordTable->RecordCount;
  InputDB* record;
  AnsiString log_date, plate_number;
  int record_total = DataModule2->CarRecordTable->RecordCount;
  for (int record_index = 0; record_index < record_total; record_index++) {
    record = &inputdb[record_index];
    record->serial_no    = DataModule2->CarRecordTable->FieldByName("SerialNo")->AsInteger;
    log_date     = DataModule2->CarRecordTable->FieldByName("LogDate")->AsString;
    strcpy(record->log_date, log_date.c_str());
    plate_number = DataModule2->CarRecordTable->FieldByName("PlateNumber")->AsString;
    strcpy(record->plate_number, plate_number.c_str());
    record->region_code  = DataModule2->CarRecordTable->FieldByName("RegionCode")->AsInteger;
    DataModule2->CarRecordTable->Next();
  }
  line_total = record_total;
}

void WriteDataBaseTravelTime(std::list<OutputTravelDB*>& output_list) {
  DataModule2->TravelTimeTable->Edit();
  DataModule2->TravelTimeTable->Insert();
  std::list<OutputTravelDB*>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->TravelTimeTable->Insert();
    DataModule2->TravelTimeTable->FieldByName("TravelID")->AsInteger = output_iter->travel_id;
    DataModule2->TravelTimeTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->TravelTimeTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->TravelTimeTable->FieldByName("dTime")->AsInteger = output_iter->d_time;
    DataModule2->TravelTimeTable->Post();
  }
}

void WriteDataBaseCongest(std::list<OutputCongestDB*>& output_list) {
  DataModule2->CongestionTable->Edit();
  DataModule2->CongestionTable->Insert();
  std::list<OutputCongestDB*>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->CongestionTable->Insert();
    DataModule2->CongestionTable->FieldByName("TrafficID")->AsInteger = output_iter->traffic_id;
    DataModule2->CongestionTable->FieldByName("EquID")->AsInteger = output_iter->equid;
    DataModule2->CongestionTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->CongestionTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->CongestionTable->FieldByName("Val")->AsInteger = output_iter->val;
    DataModule2->CongestionTable->Post();
  }
}

void WriteDataBaseCarCount(std::list<OutputCountDB>& output_list) {
  DataModule2->CarCountTable->Edit();
  DataModule2->CarCountTable->Insert();
  std::list<OutputCountDB>::iterator output_iter;
  for (output_iter=output_list.begin(); output_iter!=output_list.end(); ++output_iter) {
    DataModule2->CarCountTable->Insert();
    DataModule2->CarCountTable->FieldByName("TrafficID")->AsInteger = output_iter->traffic_id;
    DataModule2->CarCountTable->FieldByName("EquID")->AsInteger = output_iter->equid;
    DataModule2->CarCountTable->FieldByName("CreateTime")->AsString = output_iter->create_time;
    DataModule2->CarCountTable->FieldByName("DateTime")->AsString = output_iter->data_time;
    DataModule2->CarCountTable->FieldByName("Val")->AsInteger = output_iter->val;
    DataModule2->CarCountTable->Post();
  }
}

void DBToText() {
  int record_total = DataModule2->CarRecordTable->RecordCount;
  int serial_no, region_code;
  AnsiString log_date, plate_number;
  FILE* fptr = fopen("CarRecord0103.txt", "w");
  DataModule2->CarRecordTable->Refresh();
  DataModule2->CarRecordTable->First();
  for (int record_index = 0; record_index < record_total; record_index++) {
    serial_no    = DataModule2->CarRecordTable->FieldByName("SerialNo")->AsInteger;
    log_date     = DataModule2->CarRecordTable->FieldByName("LogDate")->AsString;
    plate_number = DataModule2->CarRecordTable->FieldByName("PlateNumber")->AsString;
    region_code  = DataModule2->CarRecordTable->FieldByName("RegionCode")->AsInteger;
    fprintf(fptr, "%d,%s,%s,%d\n", serial_no, log_date, plate_number, region_code);
    DataModule2->CarRecordTable->Next();
  }
  fclose(fptr);
}

void DBTrafficInfoToText() {
  int record_total = DataModule2->TrafficInfoTable->RecordCount;
  int region_code, type;
  FILE* fptr = fopen("TrafficInfo.txt", "w");
  DataModule2->TrafficInfoTable->Refresh();
  DataModule2->TrafficInfoTable->First();
  for (int record_index = 0; record_index < record_total; record_index++) {
	region_code  = DataModule2->TrafficInfoTable->FieldByName("RegionCode")->AsInteger;
	type  = DataModule2->TrafficInfoTable->FieldByName("Type")->AsInteger;
	fprintf(fptr, "%d,%d\n", region_code, type);
	DataModule2->TrafficInfoTable->Next();
  }
  fclose(fptr);
}
*/




