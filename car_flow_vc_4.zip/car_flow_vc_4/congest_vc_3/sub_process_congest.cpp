
#include <stdio.h>

#include <list>

#include "data_member.h"
#include "data_transfer.h"
#include "data_display.h"
#include "extract_interval_data.h"
#include "manager_time.h"
#include "single_camera_io.h"
#include "traffic_analysis.h"

void CongestionProcess(int camera_id, int camera_num, int time_start, int time_inteval,
                       int time_period, 
                       std::list<OutputCongestDB*> &output_list_congest) {
  // 1. Check time interval is bigger than period.
  if (time_inteval < time_period) return;
  // 2. Read specific camera data.
  std::list<InputMDB> scamr_list, interval_list;
  SingleCameraIO scamr_io;
  scamr_io.set_list(scamr_list);
  scamr_io.ReadSingleCameraData(camera_num);
  // 3. Prepare a calculate list for analysis process.
  std::list<CalData> cal_list;
  // 4. Set up data transfer process.
  DataTransfer transfer;
  transfer.set_callist(cal_list);
  // 5. Set up congest analysis process
  TrafficAnalysis analysis;
  analysis.set_callist(cal_list);
  //
  DataListDisplay display;
 // display.Show(scamr_list);
 // getchar();
  // 6. Set up Extract interval data process.
  ExtractIntervalData extract;
  extract.set_raw_list(scamr_list);
  extract.set_interval_list(interval_list);
  printf("Extract ------ \n");
  // 7. Revise start time to be divided with no remainder.
  time_start = StartTimeRevise(time_start, time_period);
  int time_total = time_start + time_inteval;
  for (int time_index = time_start + time_period; time_index < time_total;
       time_index+=time_period) {
    // 1. Extract interval data 
    extract.Extract(time_index - time_period, time_index);
    // 2. Transfer interval data to calculate data.
    transfer.set_classlist(interval_list);
    transfer.ClassToCal();
    // 3. Analysis interval data and form congestion values.
    analysis.Analysis();
    // 4. Do intergrate process, put result to ouput list.
    transfer.InsertCongest(camera_id, camera_num, time_index,
                           output_list_congest);
    //display.Show(output_list_congest);
    //getchar();
  }
}

void CarCountProcess(int camera_id, int camera_num, int time_start, int time_inteval,
                       int time_period, 
                       std::list<OutputCountDB*> &output_list_congest) {
  // 1. Check time interval is bigger than period.
  if (time_inteval < time_period) return;
  // 2. Read specific camera data.
  std::list<InputMDB> scamr_list, interval_list;
  SingleCameraIO scamr_io;
  scamr_io.set_list(scamr_list);
  scamr_io.ReadSingleCameraData(camera_num);
  // 3. Prepare a calculate list for analysis process.
  std::list<CalData> cal_list;
  // 4. Set up data transfer process.
  DataTransfer transfer;
  transfer.set_callist(cal_list);
  // 5. Set up congest analysis process
  TrafficAnalysis analysis;
  analysis.set_callist(cal_list);
  //
  DataListDisplay display;
  //display.Show(scamr_list);
  // 6. Set up Extract interval data process.
  ExtractIntervalData extract;
  extract.set_raw_list(scamr_list);
  extract.set_interval_list(interval_list);
  printf("Extract ------ \n");
  // 7. Revise start time to be divided with no remainder.
  time_start = StartTimeRevise(time_start, time_period);
  int time_total = time_start + time_inteval;
  for (int time_index = time_start + time_period; time_index < time_total;
       time_index+=time_period) {
    // 1. Extract interval data 

    extract.Extract(time_index - time_period, time_index);
    // 2. Transfer interval data to calculate data.
    transfer.set_classlist(interval_list);
    transfer.ClassToCal();
    // 3. Analysis interval data and form congestion values.
    analysis.Analysis();
    // 4. Do intergrate process, put result to ouput list.
    transfer.InsertCarCount(camera_id, camera_num, time_index,
                           output_list_congest);
    //display.Show(interval_list);
    //getchar();
  }
}
