#include "single_camera_io.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

SingleCameraIO::SingleCameraIO() {
  file_data_ = NULL;
}
SingleCameraIO::~SingleCameraIO() {
  if (file_data_ != NULL) delete[] file_data_;
}


void SingleCameraIO::ReadSingleCameraData(int id) {
  // Make list container empty.
  scamr_list_->clear();
  // Read number of record from file.
  char filename[15];
  sprintf(filename, "temp/m%d.bin", id);
  FILE *fptr = fopen(filename, "rb");
  if (fptr == NULL) { 
    printf("\"%s\" can't be find.\n", filename);
    return;
  }
  int record_total;
  size_t size = sizeof(int);
  size_t count = 1;
  fread(&record_total, size, count, fptr);
  // New a suitable stack to "InputDB" container.
  size = sizeof(InputMDB);
  count = record_total;
  //fread(&filedata_, size, count, fptr);
  file_data_ = new InputMDB[record_total];
  fread(file_data_, size, count, fptr);
  fclose(fptr);
  int record_index = record_total - 1;
  while (record_index--) {
    scamr_list_->push_front(file_data_[record_index]);
  }
  FilterDuplicate(*scamr_list_);
}

void SingleCameraIO::FilterDuplicate(std::list<InputMDB> &input_list) {
  char plate_number[100];
  strcpy(plate_number, "AKB48");
  int time = -1;
  std::list<InputMDB>::iterator input_iter;
  for (input_iter=input_list.begin(); input_iter!=input_list.end(); ) {
    if (!strcmp(input_iter->plate_number, plate_number)) {
      input_iter = input_list.erase (input_iter);
      continue;
    }
    if (input_iter->log_date == time) {
      input_iter = input_list.erase (input_iter);
      continue;
    }

    strcpy(plate_number, input_iter->plate_number);
    time = input_iter->log_date;
    ++input_iter;

  }

}
