#include "initial_setting.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "manager_time.h"

// InitialCondiation public member -------------------------------------------
InitialCondition::InitialCondition() {
}

void InitialCondition::Initailize() {
  printf("Mark: %d %d\n", CurrentDailyMark(), SecFromMidnight());
  time_current_ = SecFromMidnight();
  ReadIniFile();
  ReadUserInterface();
}


int InitialCondition::Period(ProcessType type) {
  switch (type) {
    case kTravel: {
      return period_travel_;   
    }
    case kCongest: {
      return period_congest_;   
    }
    case kCarCount: {
      return period_carcount_;   
    }
    default: {
      assert(false);
    }
  }
}

int InitialCondition::Inteval(ProcessType type) {
  switch (type) {
    case kTravel: {
      int inteval = time_current_ - last_time_travel_ - time_delay_;
      if (inteval < 0) inteval = 0;
      return inteval;   
    }
    case kCongest: {
      int inteval = time_current_ - last_time_congest_ - time_delay_;
      if (inteval < 0) inteval = 0;
      return inteval;   
    }
    case kCarCount: {
      int inteval = time_current_ - last_time_carcount_ - time_delay_;
      if (inteval < 0) inteval = 0;
      return inteval;   
    }
    default: {
      assert(false);
    }
  }
}

int InitialCondition::LastTime(ProcessType type) {
  switch (type) {
    case kTravel: 
      return last_time_travel_;   
    case kCongest: 
      return last_time_congest_;   
    case kCarCount: 
      return last_time_carcount_;   
    default: {
      assert(false);
    }
  }
}

void InitialCondition::End(int last_id, int last_time_travel,
                           int last_time_congest, int last_time_carcount) {
  last_id_ = last_id;
  int total, period;
  total = LastTime(kTravel) + Inteval(kTravel);
  period = Period(kTravel);
  last_time_travel_ = StartTimeRevise(total, period);
  total = LastTime(kCongest) + Inteval(kCongest);
  period = Period(kCongest);
  last_time_congest_= StartTimeRevise(total, period);;
  total = LastTime(kCarCount) + Inteval(kCarCount);
  period = Period(kCarCount);
  last_time_carcount_= StartTimeRevise(total, period);;
  WriteIniFile();
}
// InitialCondiation private member -------------------------------------------
void InitialCondition::ReadIniFile() {
  char* filename = "temp/ini.bin";
  FILE *fptr = fopen(filename, "rb");
  if (fptr == NULL) { 
    ParameterNewDaySetting();
    ClearTempFile();
  } else {
    size_t size = sizeof(int);
    size_t count = 1;
    fread(&daily_mark_, size, count, fptr);
    fread(&last_id_, size, count, fptr);
    fread(&last_time_travel_, size, count, fptr);
    fread(&last_time_congest_, size, count, fptr);
    fread(&last_time_carcount_, size, count, fptr);
    if (daily_mark_ != CurrentDailyMark()) {
       ParameterNewDaySetting();
       ClearTempFile();
    }
    fclose(fptr);
  }
}

void InitialCondition::WriteIniFile() {
  char* filename = "temp/ini.bin";
  FILE *fptr = fopen(filename, "wb");
  size_t size = sizeof(int);
  size_t count = 1;
  fwrite(&daily_mark_, size, count, fptr);
  fwrite(&last_id_, size, count, fptr);
  fwrite(&last_time_travel_, size, count, fptr);
  fwrite(&last_time_congest_, size, count, fptr);
  fwrite(&last_time_carcount_, size, count, fptr);
  fclose(fptr);
}

void InitialCondition::ReadUserInterface() {
  char* filename = "user/time.txt";
  FILE *fptr = fopen(filename, "r");
  if (fptr == NULL) { 
    printf("User control file lack! system stop.\n");
    getchar();
  } 
  char sread[4][100];
  fgets(sread[0], 100, fptr);
  fgets(sread[1], 100, fptr);
  fgets(sread[2], 100, fptr);
  fgets(sread[3], 100, fptr);
  fclose(fptr);
  sscanf(sread[0], "%*[^':']:%d", &period_travel_);
  sscanf(sread[1], "%*[^':']:%d", &period_congest_);
  sscanf(sread[2], "%*[^':']:%d", &period_carcount_);
  sscanf(sread[3], "%*[^':']:%d", &time_delay_);
}

int InitialCondition::CurrentDailyMark() {
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  int mark = timeinfo->tm_year * 10000 + timeinfo->tm_mon * 100 + timeinfo->tm_mday;
  return mark;
  //printf("%d %02d %d\n", timeinfo->tm_year, timeinfo->tm_mon + 1, timeinfo->tm_mday);
}

int InitialCondition::SecFromMidnight() {
  time_t rawtime;
  struct tm * timeinfo;
  time(&rawtime);
  timeinfo = localtime (&rawtime);
  int sec = timeinfo->tm_hour * 3600 + timeinfo->tm_min * 60 + timeinfo->tm_sec;
  return sec;
}

void InitialCondition::ParameterNewDaySetting() {
  daily_mark_ = CurrentDailyMark();
  last_id_ = 0;
  last_time_travel_ = 0;
  last_time_congest_= 0;
  last_time_carcount_= 0;
}

void InitialCondition::ClearTempFile() {
  char filename[100];
  for (int index = 0; index < 100; index++) {
    sprintf(filename, "temp/%d.bin", index);
    remove(filename);
    sprintf(filename, "temp/m%d.bin", index);
    remove(filename);
  }
}

/*
int ReadIniInf() {
  char* filename = "ini.bin";
  FILE *fptr = fopen(filename, "rb");
  if (fptr == NULL) { 
    //fclose(fptr);
    return 0;
  }
  int pos_ini;
  size_t size = sizeof(int);
  size_t count = 1;
  fread(&pos_ini, size, count, fptr);
  fclose(fptr);
  return pos_ini;
}

void WriteIniInf(int pos_fal) {
  char* filename = "ini.bin";
  FILE *fptr = fopen(filename, "wb");
  size_t size = sizeof(int);
  size_t count = 1;
  fwrite(&pos_fal, size, count, fptr);
  fclose(fptr);
}
*/
