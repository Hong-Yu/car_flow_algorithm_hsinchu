#ifndef READ_ROAD_INFO_H_
#define READ_ROAD_INFO_H_
#include <SQLAPI.h>
#include <vector>
#include "data_member.h"

class ReadRoadInfo {
 public:
   ReadRoadInfo(SAConnection* con_output);
   ~ReadRoadInfo();
   int Total() { return road_list_.size(); }
   std::vector<int> get_camera_start(int road_index) { 
     return road_list_[road_index]->camera_start; 
   }
   std::vector<int> get_camera_end(int road_index) { 
     return road_list_[road_index]->camera_end; 
   }
   bool get_is_adequate(int road_index) {
     return road_list_[road_index]->is_adequate; 
   }
   int get_default_time(int road_index) {
     return road_list_[road_index]->default_time; 
   }
   int RoadId(int index) { return road_list_[index]->id; }
 private:
   void Initialize();
   void ReadDatabase();
   RoadDB* AssignCameraGroup(int id, const char* pass_car_id, int default_time);
   void SplitToString(const char* source, char separator, char (*res)[100]);
   void SplitToint(const char* source, char separator, std::vector<int>& result);
   //void ReadDatabase();
   std::vector<RoadDB*> road_list_;
   std::vector<int> camera_begin_;
   std::vector<int> camera_end_;
   SAConnection* con_output_;
};


#endif // READ_ROAD_INFO_H_
