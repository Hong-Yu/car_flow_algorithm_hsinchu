#include "read_traffic_info.h"

#include <stdio.h>

//#include "data_module.h"

using namespace std;
//ReadTrafficInfo public member ------------------------------------------------
ReadTrafficInfo::ReadTrafficInfo(SAConnection* con_output){
  con_output_ = con_output;
  Initialize();
}
ReadTrafficInfo::~ReadTrafficInfo(){
}
void ReadTrafficInfo::Initialize(){
  ReadDatabase();
}
//ReadTrafficInfo private member -----------------------------------------------

void ReadTrafficInfo::ReadText() {
  // prepare container for reading
  int camera_id, type;
  // read information from file into vector.
  FILE* fptr = fopen("src/TrafficInfo.txt", "r");
  if (fptr == NULL) {
    printf("Open file fail: TrafficInfo.txt\n");
    getchar();
  }
  char rline[200];
  while (fgets(rline, 200, fptr) != NULL) {
	if (rline[0] == '\n') continue;
	sscanf(rline, "%d,%d", &camera_id, &type);
    if (!type)
      camera_id_vector_.push_back(camera_id);
  }
  fclose(fptr);
}

void ReadTrafficInfo::ReadDatabase() {
  SACommand cmd_select;
  cmd_select.setConnection(con_output_);
  char text_select[200];
  char* col_name_a = "Type, id, RegionCode";
  sprintf(text_select, "Select %s from TrafficInfo where RegionCode is not NULL", col_name_a);
  int record_index = 0;
  int camera_id, cameta_num, type;
  try {
    cmd_select.setCommandText(text_select);
    cmd_select.Execute();
    while (cmd_select.FetchNext()) { 
      if (cmd_select.Field("Type").asLong()) continue;
      camera_id = cmd_select.Field("id").asLong();
      cameta_num = cmd_select.Field("RegionCode").asLong();
      camera_id_vector_.push_back(camera_id);
      camera_num_vector_.push_back(cameta_num);
      ++record_index;
    }
  } catch (SAException &x) {
    printf("%s \n", (const char*)x.ErrText());
    getchar();
  }
  printf("Total Camera %d\n", record_index);
}
/*
void ReadTrafficInfo::ReadDatabase() {
  // prepare container for reading
  int camera_id, cameta_num, type;
  // read information from file into vector.
  int record_total = DataModule2->TrafficInfoTable->RecordCount;
  DataModule2->TrafficInfoTable->Refresh();
  DataModule2->TrafficInfoTable->First();
  for (int record_index = 0; record_index < record_total; record_index++) {

    type  = DataModule2->TrafficInfoTable->FieldByName("Type")->AsInteger;
    if (!type) {
      camera_id = DataModule2->TrafficInfoTable->FieldByName("id")->AsInteger;
      cameta_num = DataModule2->TrafficInfoTable->FieldByName("RegionCode")->AsInteger;
      camera_id_vector_.push_back(camera_id);
      camera_num_vector_.push_back(cameta_num);
    }
    DataModule2->TrafficInfoTable->Next();
  }
}
*/

