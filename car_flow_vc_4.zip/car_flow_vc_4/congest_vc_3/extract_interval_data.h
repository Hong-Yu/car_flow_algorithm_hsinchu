#ifndef EXTRACT_INTERVAL_DATA_H_
#define EXTRACT_INTERVAL_DATA_H_
#include <list>
#include "data_member.h"

class ExtractIntervalData {
public:
  ExtractIntervalData();
  ~ExtractIntervalData();
  void set_raw_list(std::list<InputMDB> &raw_list) { 
    raw_list_ = &raw_list; 
  }
  void set_interval_list(std::list<InputMDB> &interval_list) { 
    interval_list_ = &interval_list; 
  }
  void Extract(int time_start, int time_end);
  void Extract(int time_end);
private:
  std::list<InputMDB>* raw_list_;
  std::list<InputMDB>* interval_list_;

};


#endif // EXTRACT_INTERVAL_DATA_H_